let scene, camera, renderer;
let player, bullets = [], enemies = [];
let keys = {};
let started = false;
let velocityY = 0;
let onGround = true;

// ================= MENU =================
function startGame(){
    document.getElementById("menu").style.display = "none";
    init();
    animate();
}

// ================= INIT =================
function init(){
    started = true;

    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87ceeb);

    camera = new THREE.PerspectiveCamera(
        75,
        window.innerWidth / window.innerHeight,
        0.1,
        1000
    );

    renderer = new THREE.WebGLRenderer({ antialias:true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(renderer.domElement);

    // Lumières
    scene.add(new THREE.AmbientLight(0xffffff, 0.5));
    const sun = new THREE.DirectionalLight(0xffffff, 1);
    sun.position.set(10, 20, 10);
    scene.add(sun);

    // Sol (arène)
    const ground = new THREE.Mesh(
        new THREE.CircleGeometry(50, 64),
        new THREE.MeshStandardMaterial({ color:0x2ecc71 })
    );
    ground.rotation.x = -Math.PI/2;
    scene.add(ground);

    // Joueur
    player = new THREE.Mesh(
        new THREE.BoxGeometry(1,2,1),
        new THREE.MeshStandardMaterial({ color:0x3498db })
    );
    player.position.y = 1;
    scene.add(player);

    // Ennemis
    for(let i=0;i<6;i++){
        spawnEnemy();
    }

    // Contrôles
    document.addEventListener("keydown", e => keys[e.key.toLowerCase()] = true);
    document.addEventListener("keyup", e => keys[e.key.toLowerCase()] = false);

    document.addEventListener("click", shoot);

    window.addEventListener("resize", onResize);
}

// ================= ENNEMI =================
function spawnEnemy(){
    const e = new THREE.Mesh(
        new THREE.BoxGeometry(1.2,2,1.2),
        new THREE.MeshStandardMaterial({ color:0xe74c3c })
    );
    e.position.set(
        Math.random()*40-20,
        1,
        Math.random()*40-20
    );
    enemies.push(e);
    scene.add(e);
}

// ================= TIR =================
function shoot(){
    if(!started) return;

    const bullet = new THREE.Mesh(
        new THREE.SphereGeometry(0.15),
        new THREE.MeshBasicMaterial({ color:0xffff00 })
    );
    bullet.position.copy(player.position);
    bullet.velocity = new THREE.Vector3(0,0,-1).applyQuaternion(camera.quaternion);
    bullets.push(bullet);
    scene.add(bullet);
}

// ================= LOOP =================
function animate(){
    requestAnimationFrame(animate);

    // Déplacements
    if(keys["z"]) player.position.z -= 0.15;
    if(keys["s"]) player.position.z += 0.15;
    if(keys["q"]) player.position.x -= 0.15;
    if(keys["d"]) player.position.x += 0.15;

    // Saut
    if(keys[" "] && onGround){
        velocityY = 0.35;
        onGround = false;
    }

    velocityY -= 0.02;
    player.position.y += velocityY;
    if(player.position.y <= 1){
        player.position.y = 1;
        velocityY = 0;
        onGround = true;
    }

    // Caméra 3e personne
    camera.position.set(
        player.position.x,
        player.position.y + 6,
        player.position.z + 10
    );
    camera.lookAt(player.position);

    // Balles
    bullets.forEach((b, i)=>{
        b.position.add(b.velocity);
        enemies.forEach((e, ei)=>{
            if(b.position.distanceTo(e.position) < 1){
                scene.remove(e);
                enemies.splice(ei,1);
                spawnEnemy();
            }
        });
    });

    // Ennemis suivent
    enemies.forEach(e=>{
        e.lookAt(player.position);
        e.position.add(
            e.getWorldDirection(new THREE.Vector3()).multiplyScalar(0.04)
        );
    });

    renderer.render(scene, camera);
}

// ================= RESIZE =================
function onResize(){
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}
