/***********************************************/
/**                                            */
/**              MINI-PROJET JS 2015           */
/**                                            */
/***********************************************/

/** placez ici votre code javascript réponse aux questions du sujet de projet */

/** n'oubliez pas de faire précéder le code de vos fonctions 
    d'un commentaire documentant la fonction                   **/
	
//                  Variables liées à l'affichage du jeu
	
var myCanvas;                                 // variable permettant de prendre le focus sur le canvas
var context;                                  // variable permettant de définir le context du canevas
var refresh;                                  // var servant à annuler le RAF
var score;                                    // variable permettant de moduler le score en prennant l'élement HTML
var viejoueur;                                // var permettant de prendre le focus sur la zone indiquant les vies du joueur
	
//                  Variables liés à la positsition et à l'animation

var joueur;                                   // variable qui stockera l'objet joueur
var x;                                        // position de base x
var y;              						  // position de base y
var droite;                                   // var prenant comme valeur true ou false et permettant de combiner plusieurs mouvements
var haut;                                     // var prenant comme valeur true ou false et permettant de combiner plusieurs mouvements
var bas;                                      // var prenant comme valeur true ou false et permettant de combiner plusieurs mouvements
var gauche;									  // var prenant comme valeur true ou false et permettant de combiner plusieurs mouvements 
var tirer;                                    // var prenant comme valeur true ou false et permettant de combiner plusieurs mouvements
var timeinvincible;                           // var qui contiendra un setInterval pour l'invincibilité du joueur

//                  Variables qui vont contenir des tableaux

var ttir;                                     // var qui contiendra toutes les entités de type tir du joueur
var timgtir;                                  // tableau contenant les frames des tirs du joueur
var tship;                                    // var qui contiendra toutes les entités ennemis et leurs tirs
var timgjoueur;                               // variable qui contiendra les sprites du joueur
var tmort;                                    // variable qui va contenir le tableau des morts pour faire leurs animations
var background;                               // variable permettant de stocker le background image du jeu

//                  Variables agissant sur le gameplay

var damagejoueur;                             // variable servant à donner les dommages fait par le joueur
var vitesse = 5;                              // var permettant de gérer le déplacement du joueur
var vitesse_ship = 3;                         // vitesse des ennemis
var vitesse_tir = 8 ;                         // vitesse des tirs 
var coeff_flotte;                             // variable pour augmenter l'appartion de vaisseaux au fil du jeu
var coeff_flottemax;                          // variable qui une fois atteinte, permet de limiter la difficulté
var pvredrobot;                               // Variable pour définir les pvs des robots rouges
var pvgreenrobot;                             // Variable pour définir les pvs des robots verts
var valeurgold;                               // variable qui défienira la valeur des pièces
var bluefireballup;                           // variable indiquant si la bluefireball est disponible ou non car la cumuler ne servira à rien
var coeffdroppu;                              // variable donnant la probabilité de drop des powerup par les mobs
var spawnrate ;                               // variable qui étant incrémenté augmente le taux d'ennemis
var difficulte;                               // variable qui indiquera à certaines fonction si le mode actuel est : facile/moyen/difficile

//                  Variables liées au son
 
var musique;                                  // variable qui acceuillera la musique
var coinsound;                                // var qui stockera le son des pièces
var lanceflamme;                              // var qui stockera le son du tir en continue
var soundfireball;                            // var qui stockera le bruit des fireballs
var tsoundfireball;                           // var qui stockera tous les chemins des sons de fireballs
var soundlife;                                // var qui stockera le son de la vie (power up)
var explosion;                                // var qui stockera le bruit de l'explosion
var cridragon;                                // var qui stockera le cri d'un dragon

//                 Variables liées aux bouttons

var facile;                                   // var qui sera lié à un event et permettra de démarrer une partie facile
var moyen;                                    // var qui sera lié à un event et permettra de démarrer une partie facile
var difficile;                                // var qui sera lié à un event et permettra de démarrer une partie facile
var switch_flotte;                            // var pour savoir si le boutton a été activé ou non             	
var boutton_soucoupe;                         // variable prenant le focus sur le boutton de la soucoupe
var boutton_flotte;                           // variable prenant le focus sur le boutton de la flotte
var boutton_restart;                          // var qui contiendra le focus sur le boutton restart

//                 Variables servants de compteurs utiles à des raffraichissements reguliers etc 

var defile;                                   // variable permettant de gérer l'animation du joueur (en faisant changer son sprite toutes les defile frames)
var defilee;                                  // une seconde variable atant le même principe
var defileee;                                 // une 3ème permettant de faire changer les sprites des tirs alliés
var defileeee;                                // une 4ème ayant la même utilité que la 3ème
var compteur_tir;                             // variable permettant de limiter le tir si l'on reste enfoncé



 /**************************************************************************************
 *                                        Main                                         *
 **************************************************************************************/
 
 
var modifhtml = function(){    //Fonction permettant d'implémenter du HTML pour avoir des bouttons et une zone de vie nottament.
	body=document.body;
	body.innerHTML="<canvas id='stars' width='1066' height='400'></canvas><div id='control'><button id='restart'> Restart </button><button id='nouvelleSoucoupe'>1 <img src='images/flyingSaucer-petit.png' width='48' alt='nouvelle soucoupe volante'/></button><button id='flotteSoucoupes'>&#8734; <img src='images/flyingSaucer-petit.png' width='48' alt='nouvelle soucoupe volante'/></button>Score  : <span id='score'> 0 </span>  <img id='keursurtoi'src='./images/coeur.png' >  : <span id='vies'> x0 </span></div>"
+"<div id='difficulty'><INPUT id='facile'     type= 'radio' name='dif.' value='facile'> Facile <INPUT id='moyen'      type= 'radio' name='dif.' value='moyen'> Moyen <INPUT id='difficile'  type= 'radio' name='dif.' value='difficile'> Difficile </div>";
}




var init =function(){                               //Fonction permettant d'initialiser le jeu en affectant des valeurs aux variables et en faisant des abonnements
  background = ["images/background1.png","images/background2.png","images/background3.png"];
  // Définition du canvas
  myCanvas = document.getElementById("stars");
  context = myCanvas.getContext("2d");
  y =myCanvas.height/2;
  x =40;
  
  // Var audios
  
  cridragon = new Audio();
  cridragon.src = "sounds/cridragon.wav"
  explosion = new Audio();
  explosion.src = "sounds/explosion.wav";
  explosion.volume= 0.3;
  lanceflamme = new Audio();
  soundlife = new Audio;
  soundlife.src ="sounds/life.wav";
  lanceflamme.src = "sounds/flamethrower.wav";
  lanceflamme.loop = true;
  soundfireball= new Audio();
  musique = new Audio();
  musique.volume=0.2;
  musique.src="sounds/stage1.mp3";      // charge la musique du stage 1
  musique.loop = true;
  tsoundfireball=["sounds/tir1.wav","sounds/tir2.wav","sounds/tir3.wav"];
  coinsound= new Audio();
  coinsound.src="sounds/coin.wav";
  
  
  //Setup Listener
  
  window.addEventListener("keydown",unlockKey);
  window.addEventListener("keyup",stopKey);
  
  // Vars gérant de gameplay
  
  defile = 0;                                                                                          // pour faire défiler le sprite
  defilee = 0;
  defileee = 0;
  defileeee = 0;
  compteur_tir = 0;
  coeff_flotte = 0.015;
  coeffdroppu = 0.1;           // 10 % de drop un power up
  damagejoueur = 1;
  spawnrate = 0.0005;            // à chaque ennemi tué on augmente la chance de spawn d'ennemis
  valeurgold = 5000;
  pvgreenrobot = 5;
  pvredrobot = 7;
  coeff_flottemax = 0.07;
  bluefireballup = true;
  difficulte = "facile";       // Permet de faire spawn les ennemis correspondant à une difficulté facile
  
  
  //VARS gérant les boutons
  
  facile = document.getElementById("facile");
  facile.addEventListener("click",diffacile);
  moyen = document.getElementById("moyen");
  moyen.addEventListener("click",difmoyen);
  difficile = document.getElementById("difficile");
  difficile.addEventListener("click",difdifficile);
  boutton_flotte = document.getElementById("flotteSoucoupes");
  boutton_flotte.addEventListener("click",inflotte);
  boutton_soucoupe = document.getElementById("nouvelleSoucoupe");
  boutton_soucoupe.addEventListener("click",ennemies);
  boutton_restart = document.getElementById("restart");
  boutton_restart.addEventListener("click",restart);
  switch_flotte = false;
  
  //Vars d'affichage
  
  score = document.getElementById("score");
  score.textContent = 0;
  viejoueur =document.getElementById("vies");
  tmort= [];
  ttir = new Array();
  tship = new Array();
  tpowerup=[];
  timgrobot=["images/little_green_robot1.png","images/little_red_robot1.png"];                        //le tableau d'image pour le robot
  timgjoueur = ["images/ange1.png","images/ange2.png","images/ange3.png","images/ange4.png"];         //le tableau d'image pour le joueur
  timgtir=["images/fireball1.png","images/fireball2.png","images/fireball3.png"];                     //le tableau d'images pour le tir
  myCanvas.style.backgroundImage= "url("+background[0]+")";                                           // on charge le background du level 1
  // appel de la boucle de jeu:
  joueur = new constructeur("joueur",x,y,timgjoueur[0],3,"vivant");
  viejoueur.textContent= "x"+joueur.pv;
  animation();

}


var restart = function (){                 // Fonction permettant de redémarrer le jeu  appelée quand on appui sur restart ou quand on perd
	this.blur();
	window.cancelAnimationFrame(refresh);
	musique.pause();
	lanceflamme.pause();
	init();
	
}

var endgame=function(){                   // Fonction indiquant la fin de la partie ainsi que le score. Elle redémarre ensuite le jeu
	window.alert(" Vous avez perdu ! \n Votre score est de :" +score.textContent );
	restart();
}

var animation = function(){                                          // Fonction gérant les boucles principales d'animations du jeu.  C'est le corps du jeu

	context.clearRect(0,0,myCanvas.width, myCanvas.height);          // On efface tout

	context.drawImage(joueur.img,x,y);                               // On place le joueur

	for(var i = 0; i < ttir.length; i++){                            //Boucle mouvement des tirs alliés (le ttir.length s'actualise automatiquement)
		var tir = ttir[i];
		context.drawImage( ttir[i].img , tir.x, tir.y);              // on les dessines
		if(tir.x > (myCanvas.width+tir.img.width)){                  // Tant qu'il n'est pas complétement sorti du Canvas on ne le supprime pas
			ttir.splice(i,1);                                        
			i--;                                                     // on décrémente pour ne pas louper de tirs
		}	
		else{
			tir.x += vitesse_tir;                                    // Si elle ne sort pas on le fait avancer
		}
	}
	
	if (coeff_flotte>coeff_flottemax){
		coeff_flotte= coeff_flottemax;
	}
	flotte();                                                        // Fonction rajouttant des ennemis si le boutton flotte est activé
	
	for(var i = 0; i < tship.length; i++){                           // Boucle de mouvement des entités ennemies
		context.drawImage(tship[i].img, tship[i].x, tship[i].y);     // on le dessine
		if (tship[i].x<=(0-tship[i].img.width)){                     // Tant qu'il n'est pas complétement sorti du Canvas on ne le supprime pas
			tship.splice(i,1);
			i--;
			score.textContent=parseInt(score.textContent) -500;      // On perd des points si il sort de l'écran
			}
		else{
			tship[i].x -= tship[i].vitesse;                              // si il ne sort pas on le fait avancer
		
		
			if (tship[i].type=="redrobot" && Math.random()<0.003){       // Si un ennemi est un robot rouge, il a une chance de tirer
				tir_ennemies(tship[i].x,tship[i].y);
			}
			else if (tship[i].type=="greendragon" && Math.random()<0.01){       // Si un ennemi est un dragon vert il a une chance de tirer
				tir_greendragon(tship[i].x,(tship[i].y+(tship[i].img.height*Math.random())));
			}
			else if (tship[i].type=="blackdragon" && Math.random()<0.01){       // Si un ennemi est un dragon vert il a une chance de tirer
				tir_blackdragon(tship[i].x,(tship[i].y+(tship[i].img.height*Math.random())));
			}			
		}
	}
	
	
	move();                                                          // appel de la fonction gérant les actions du joueur
	joueur.x=x;                                                      // on affecte les coordonnées globales aux propriétés de l'objet joueur
	joueur.y=y;
	anim_joueur();                                                   // appel de la fonction gérant le changement de sprites du joueur
	anim_tir();                                                      // appel de la fonction gérant le changement de sprites des tirs du joueur
	if(PV()){                                                        // appel de la fonction supprimant toutes les entités dont leurs pv seraient <= 0
		return;                                                      // si le joueur est mort, alors la fonction renvoie true ce qui permet de lancer un return 
	};                                                               // vide et de ne pas faire le reste de la fonction qui serait innutile
	tirReussi();                                                     //appel de la fonction gérant les collisions tir allié/entités ennemies
	
	
	
	if (joueur.etat =="vivant" ){  // si le joueur est dans un état normal, on vérifie si il est en collision
		collision_joueur();
		}
	
	
	for (i=0;i<tpowerup.length;i++){      								// Boucle gérant le déplacement des power up
		tpowerup[i].x-=tpowerup[i].vitesse;
		context.drawImage(tpowerup[i].img,tpowerup[i].x,tpowerup[i].y);
	}
	
	if (tpowerup.length!=0){     // Si il y a des power up
		collisionpowerup();      // On vérifie si il y a une collision avec le joueur
	}
	
	for (i=0;i<tmort.length;i++){                                             // boucle qui va gérer l'animation de la mort des ennemis
	
		if (tmort[i].type== "greenrobot" || tmort[i].type== "redrobot"){      // si les ennemis sont des robots
			if(tmort[i].mort<5){                                              // on regarde leur propriété mort
				tmort[i].img.src = "images/explosion1.png";                   // on défini l'image à afficher
				context.drawImage(tmort[i].img,tmort[i].x,tmort[i].y);        // on l'affiche
				tmort[i].mort++;                                              // on passe à l'étape suivante
			} 
			else if (tmort[i].mort<10){                                       // si la mort est dans un autre stade on change d'image
				tmort[i].img.src = "images/explosion2.png";
				context.drawImage(tmort[i].img,tmort[i].x,tmort[i].y);
				tmort[i].mort++;
			}
			else if (tmort[i].mort<15){                                        // on change d'images
				tmort[i].img.src = "images/explosion3.png";
				context.drawImage(tmort[i].img,tmort[i].x,tmort[i].y);
				tmort[i].mort++;
			}
			else if (tmort[i].mort<20){                                        // on change pour la dernière image
				tmort[i].img.src = "images/explosion4.png";
				context.drawImage(tmort[i].img,tmort[i].x,tmort[i].y);				
				tmort[i].mort++;
			}
			else{                                                              // si l'ennemi est assez avancé dans la mort il disparaît pour de bon
				tmort.splice(i,1);
				i--;
			}
		}
		
		else if (tmort[i].type== "coinrobot"){      // si l'ennemi est un robot coin
			if(tmort[i].mort<5){                                              // on regarde leur propriété mort
				tmort[i].img.src = "images/grandeexplosion1.png";                   // on défini l'image à afficher
				context.drawImage(tmort[i].img,tmort[i].x,tmort[i].y);        // on l'affiche
				tmort[i].mort++;                                              // on passe à l'étape suivante
			} 
			else if (tmort[i].mort<10){                                       // si la mort est dans un autre stade on change d'image
				tmort[i].img.src = "images/grandeexplosion2.png";
				context.drawImage(tmort[i].img,tmort[i].x,tmort[i].y);
				tmort[i].mort++;
			}
			else if (tmort[i].mort<15){                                        // on change d'images
				tmort[i].img.src = "images/grandeexplosion3.png";
				context.drawImage(tmort[i].img,tmort[i].x,tmort[i].y);
				tmort[i].mort++;
			}
			else if (tmort[i].mort<20){                                        // on change pour la dernière image
				tmort[i].img.src = "images/grandeexplosion4.png";
				context.drawImage(tmort[i].img,tmort[i].x,tmort[i].y);				
				tmort[i].mort++;
			}
			else{                                                              // si l'ennemi est assez avancé dans la mort il disparaît pour de bon
				tmort.splice(i,1);
				i--;
			}
			
		}
		
		
		else if (tmort[i].type== "blackdragon"){      // si l'ennemi est un robot coin
			if(tmort[i].mort<5){                                              // on regarde leur propriété mort
				tmort[i].img.src = "images/blackdragondeath1.png";                   // on défini l'image à afficher
				context.drawImage(tmort[i].img,tmort[i].x,tmort[i].y);        // on l'affiche
				tmort[i].mort++;                                              // on passe à l'étape suivante
			} 
			else if (tmort[i].mort<10){                                       // si la mort est dans un autre stade on change d'image
				tmort[i].img.src = "images/blackdragondeath2.png";
				context.drawImage(tmort[i].img,tmort[i].x,tmort[i].y);
				tmort[i].mort++;
			}
			else if (tmort[i].mort<15){                                        // on change d'images
				tmort[i].img.src = "images/blackdragondeath3.png";
				context.drawImage(tmort[i].img,tmort[i].x,tmort[i].y);
				tmort[i].mort++;
			}
			else if (tmort[i].mort<20){                                        // on change pour la dernière image
				tmort[i].img.src = "images/blackdragondeath4.png";
				context.drawImage(tmort[i].img,tmort[i].x,tmort[i].y);				
				tmort[i].mort++;
			}
			else{                                                              // si l'ennemi est assez avancé dans la mort il disparaît pour de bon
				tmort.splice(i,1);
				i--;
			}
			
		}
		
		else if (tmort[i].type== "greendragon"){      // si l'ennemi est un robot coin
			if(tmort[i].mort<5){                                              // on regarde leur propriété mort
				tmort[i].img.src = "images/greendragondeath1.png";                   // on défini l'image à afficher
				context.drawImage(tmort[i].img,tmort[i].x,tmort[i].y);        // on l'affiche
				tmort[i].mort++;                                              // on passe à l'étape suivante
			} 
			else if (tmort[i].mort<10){                                       // si la mort est dans un autre stade on change d'image
				tmort[i].img.src = "images/greendragondeath2.png";
				context.drawImage(tmort[i].img,tmort[i].x,tmort[i].y);
				tmort[i].mort++;
			}
			else if (tmort[i].mort<15){                                        // on change d'images
				tmort[i].img.src = "images/greendragondeath3.png";
				context.drawImage(tmort[i].img,tmort[i].x,tmort[i].y);
				tmort[i].mort++;
			}
			else if (tmort[i].mort<20){                                        // on change pour la dernière image
				tmort[i].img.src = "images/greendragondeath4.png";
				context.drawImage(tmort[i].img,tmort[i].x,tmort[i].y);				
				tmort[i].mort++;
			}
			else{                                                              // si l'ennemi est assez avancé dans la mort il disparaît pour de bon
				tmort.splice(i,1);
				i--;
			}
			
		}

	}
	refresh = window.requestAnimationFrame(animation);

}



var anim_joueur = function(){                                  // Fontion permettant de changer le skin du perso toutes les 20 frames
	defile ++;
	defile = defile % 10;                                      // Toutes les 10 Frames 
	if (defile == 0){                                          // on change l'image du joueur               
		defilee ++;
		defilee = defilee%((timgjoueur.length));
		joueur.img.src = timgjoueur[defilee];
	}
	if(joueur.etat=="invincible" && defile==5){                // On fait clignoter le joueur en cas de dégats subits
		joueur.img.src="images/transparent.png";
	}
		
	
}


var anim_tir= function(){                                      //Fonction servant à animer les tirs toutes les 20 frames (change de skin)
	defileee++;
	defileee=defileee%20;                                      // Toutes les 10 frames
	if (defileee==0){
		defileeee++;
		defileeee=defileeee%3;
		for (i=0;i<ttir.length;i++){ 
			ttir[i].img.src=timgtir[defileeee];                // on change leurs images
		}
	}
}


var move =function(){        // Fonction gérant les actions du joueur
  if ( bas == true ){        // Si la touche bas a été actionnée
	mvmtbas();}              // on le fait se déplacer en bas
  if ( gauche == true ){     // même principe
	mvmtgauche();}           
  if ( haut == true ){       // idem ici
	mvmthaut();}
  if ( droite == true ){     // encore pareil 
	mvmtdroit();}
  if ( tirer == true ) {     // si la touche de tir est enclenchée
		compteur_tir++;      // on incrémente le compteur
		compteur_tir=compteur_tir%3;                 // Ce compteur permet de limiter les tirs sinon c'est trop facile 
		if (compteur_tir==0){                // il déclenche le tir 1 fois sur 3
			tir();}
	}
}

 /**************************************************************************************
 *                                Déplacements & Tir                                   *
 **************************************************************************************/
 // FONCTIONS permettant de gerer des varialbles "haut","bas","tirer","droite"et "gauche"
 // ce qui permettra d'indiquer quelles touches sont activent à chaque frame et de ce fait
 // ça permettra d'avoir plusieurs touches enclenchées à la fois
var unlockKey = function(event){          // Fonction permettant de savoir quelles touches sont enfoncées  la fonction est associé à un event keydown
	switch(event.keyCode){                    // la structure switch permet de récuperer l'event et de faire des instructions en fonction des cas
		case 37 :                // Si la touche flèche gauche est enfoncée alors gauche = true
			gauche = true;
			droite = false;
		break;
		case 39 :               // Si la touche flèche droite est enfoncée alors droite = true
			gauche = false;
			droite = true;
		break;
		case 40 :                // Si la touche flèche du bas est enfoncée alors bas = true
			bas = true;
			haut = false;
		break;
		case 38 :                  // Si la touche flèche du haut est enfoncée alors haut = true
			haut = true;
			bas = false;
		break;
		case 32:                         // Si la touche espace gauche est enfoncée alors tirer = true
			tirer=true;
			lanceflamme.play();         // on déclenche le son
		break;
	}
} 

// Cette fonction permet quand à elle de delock les touches une fois qu'on appuie plus dessus

var stopKey = function(event) {           // Fonction permettant de savoir quelles touches sont relevées la fonction est associé à un event keyup
	switch (event.keyCode) {
		case 37 :                // Quand on arrête d'appuyer sur la flèche de gauche, gauche=false
			gauche = false ;
		break;
		case 39 :               // Quand on arrête d'appuyer sur la flèche de droite, droite=false
			droite = false ;
		break;
		case 40 :                // Quand on arrête d'appuyer sur la flèche du bas, bas=false
			bas = false ;
		break;
		case 38:                   // Quand on arrête d'appuyer sur la flèche du haut, haut=false
			haut = false ;
		break;
		case 32:                         // Quand on arrête d'appuyer sur espace, tirer=false
			tirer = false ;
		    compteur_tir=0;               // on met le le compteur de tir à 0 pour ne pas avoir des tirs vides
			lanceflamme.pause();
			soundfireball.src=tsoundfireball[Math.floor((3*Math.random()))];   // On prend un son de fireball au hasard
			soundfireball.play();                          // on le joue
		break;
  }
}
 
 
var mvmtbas= function(){                 // Fonction permettant de déplacer en bas le joueur
	if( y < myCanvas.height-joueur.img.height){      // Si c'est plus grand il sort 
	y += vitesse ;
	}
	else{                                           // On l'empêche de sortir du cadre
	y= myCanvas.height-joueur.img.height;
	}
}
var mvmthaut= function(){                // Fonction permettant de déplacer en haut le joueur
	if( y > vitesse){                             // car y-vitesse sort du cadre
	y -= vitesse ;
	}
	else{                                         // On l'empêche de sortir du cadre                              
	y= 0;
 }
}
var mvmtgauche= function(){             // Fonction permettant de déplacer à gauche le joueur
	if( x > vitesse){                            // car x-vitesse sort du cadre
	x -= vitesse ;
	}
	else{                                        // On l'empêche de sortir du cadre
	x= 0;
 }
}
var mvmtdroit= function(){             // Fonction permettant de déplacer à droite le joueur
	if( x < myCanvas.width-joueur.img.width){    //Si l'on sort pas du cadre
	x += vitesse ;
	}
	else{                                        // On l'empêche de sortir du cadre
	x= myCanvas.width-joueur.img.width; 
 }
}

 /**************************************************************************************
 *                                    Constructeurs                                    *
 **************************************************************************************/
 
 
// CONSTRUCTEUR GLOBAL


var constructeur= function (type,x,y,source,pv,etat,vitesse) {     // Fonction qui sert à construire n'importe quel type d'entité nécessaire au jeu
	this.type=type;                                                // On lui associe un type
	this.x=x;                                                      // des coordonnées
	this.y=y;
	this.pv=pv;                                                    // des pv
	this.vitesse=vitesse;                                          // une vitesse
	this.etat=etat;                                                // un état
	this.img =new Image() ;
	this.img.src =source;
}
 
var tir = function(){                          // Fonction qui déclare le tir du joueur et qui le place dans le tableau ttir
	ttir.push(new constructeur("bullet",x+35,y+30,timgtir[0],1,"vivant"));

}

var powerup = function(x,y){                  // Fonction servant à créer des power up et à les placer dans tpowerup
	var random = Math.random();
	if(0<random  &&  random<0.5){                          // on random le powerup
		if (bluefireballup==true){
			powerupbluefireball(x,y);                         // on fait pop une boule de feu bleue
		}
		else{
			powerup(x,y);                       // si on a déjà la bluefireball on relance la fonction pour avoir un autre powerup
		}
	}
	else if (0.5<random  &&  random<0.85){    
		poweruphearth(x,y);
	}
	else if (0.85<random  &&  random<1){                  // on fait pop une piece
		powerupcoin(x,y);
	}
	
}

var powerupbluefireball = function(x,y){         // Fonction faisant pop une boule de feu bleue
	tpowerup.push(new constructeur("bluefireball",x,y,"images/blue_fireball_powerup2.png",1,"vivant",2));
	bluefireballup=false;                        // pour ne pas avoir la bluefireball plusieurs fois
}

var poweruphearth = function(x,y){                // Fonction faisant pop une vie
	tpowerup.push(new constructeur("life",x,y,"images/hearth.png",1,"vivant",2));
}

var powerupcoin = function(x,y){                 // Fonction faisant pop une pièce
	tpowerup.push(new constructeur("coin",x,y,"images/coin.png",1,"vivant",2));
}



var ennemies = function (){            // Fonction ajoutant un ennemi dans le tableau des ennemis, elle appelle le constructeur
	var random = Math.random();
	this.blur();

	if(difficulte=="facile"){          //Si la difficultée est en mode facile
		if(random<0.735){               // 1/4 chances d'avoir des robots verts
			ennemi =new constructeur  ("greenrobot", myCanvas.width, 0, timgrobot[0], 5,"vivant",(3+Math.floor(Math.random()*2))) ;      // On crée un robot vert 73.5% de chance
		}
		else if(0.735<=random && random<0.985){   // ou création d'un robot rouge
			ennemi =new constructeur  ("redrobot", myCanvas.width, 0, timgrobot[1], 7,"vivant",(4+Math.floor(Math.random()*2)) );        // On crée un robot rouge 25% de chance
		}
		else if(0.985<=random && random<0.995){
			ennemi =new constructeur  ("coinrobot", myCanvas.width, 0, "images/clochekun.png", 1,"vivant",3 );                           // On crée un robot coin  1% de chance
		}
		else{
			ennemi =new constructeur  ("greendragon",myCanvas.width, 0, "images/greendragon.png", 50,"vivant",2 );                       // On crée un green dragon 0.5% de chance
		}
	}
	
	
	else if (difficulte=="moyenne"){     // Si la difficulté est moyenne
		if(random<0.610){               // 2/3 chances d'avoir des robots verts
			ennemi =new constructeur  ("greenrobot", myCanvas.width, 0, timgrobot[0], 5,"vivant",(3+Math.floor(Math.random()*2))) ;      // On crée un robot vert   61.5 % de chance
		}
		else if(0.615<=random && random<0.965){   // ou création d'un robot rouge
			ennemi =new constructeur  ("redrobot", myCanvas.width, 0, timgrobot[1], 7,"vivant",(4+Math.floor(Math.random()*2)) );        // On crée un robot rouge  35.0 % de chance
		}
		else if(0.965<=random && random<0.975){
			ennemi =new constructeur  ("coinrobot", myCanvas.width, 0, "images/clochekun.png", 1,"vivant",3 );                           // On crée un robot coin   1% de chance
		}
		else if(0.975<=random && random<0.9975){
			ennemi =new constructeur  ("greendragon", myCanvas.width, 0, "images/greendragon.png", 50,"vivant",2 );                      // On crée un dragon vert  2.25 %  de chance
		}
		else{
			ennemi =new constructeur  ("blackdragon",myCanvas.width, 0, "images/blackdragon.png", 100,"vivant",2 );		                  // On crée un dragon noir  0.25% de chance
		}
	}
	
	
	else{                                                                                                                                // Si le jeu est en difficile 
		if(random<0.555){               // 2/3 chances d'avoir des robots verts
			ennemi =new constructeur  ("greenrobot", myCanvas.width, 0, timgrobot[0], 5,"vivant",(3+Math.floor(Math.random()*2))) ;      // On crée un robot vert   55.5% de chance
		}
		else if(0.555<=random && random<0.955){   // ou création d'un robot rouge
			ennemi =new constructeur  ("redrobot", myCanvas.width, 0, timgrobot[1], 7,"vivant",(4+Math.floor(Math.random()*2)) );        // On crée un robot rouge  40 % de chance
		}
		else if(0.955<=random && random<0.965){
			ennemi =new constructeur  ("coinrobot", myCanvas.width, 0, "images/clochekun.png", 1,"vivant",3 );                           // On crée un robot coin   1% de chance
		}
		else if(0.975<=random && random<0.9975){
			ennemi =new constructeur  ("greendragon", myCanvas.width, 0, "images/greendragon.png", 50,"vivant",2 );                        // On crée un dragon vert 2.5 %  de chance
		}
		else{
			ennemi =new constructeur  ("blackdragon",myCanvas.width, 0, "images/blackdragon.png", 100,"vivant",2 );		                  // On crée un dragon noir 1 % de chance
		}
	}
		
	
	ennemi.y = (Math.random()*(myCanvas.height - 2*ennemi.img.height));      // ligne modifiant le y de l'ennemi car l'image n'existe pas encore avant d'être passé par le constructeur
	tship.push(ennemi);                                                    // on ajoute l'ennemi dans le tableau
}
	
	
	
	
	
var tir_ennemies = function(x,y){                                                // Fonction permettant de créer un tir ennemi à sa position
	tship.push(new constructeur("bullet",x,y,"images/tir.png",1,"vivant",6));
} 
var tir_greendragon = function(x,y){                                               // Fonction permettant de créer une boule de feu par un dragon vert
	tship.push(new constructeur("bullet",x,y,"images/reversebluefireball.png",1,"vivant",5));
}	
var tir_blackdragon = function(x,y){                                                // Fonction permettant de créer une boule de feu par un dragon noir
	tship.push(new constructeur("bullet",x,y,"images/reversefireball.png",1,"vivant",5));
}		


	
var inflotte =function(){           // Fonction permettant d'activer ou de desactiver l'apparition de la flotte. Elle permet d'activer et de desactiver le bouton
	this.blur();                    
	switch(switch_flotte){          // Si le boutton est desactivé, on l'active
		case false:
			switch_flotte = true;
			musique.play()
			break;
		case true:                  // Dans l'autre cas, on le desactive
			switch_flotte = false;               
			musique.pause()                       // arrête la musique
			break;
	}
}

var flotte = function(){                     // Fonction permettant de faire apparaitre une Horde d'ennemis
	if (switch_flotte == true ){             // si le boutton est activé
		if ( Math.random() < coeff_flotte ){ // Une proba de faire pop des ennemis
			ennemies();}
	};
};

 /**************************************************************************************
 *                                      Collisions                                     *
 **************************************************************************************/
	
var collision = function(entity1,entity2){        // fonction permettant de gérer les collisions
	return (Math.max(entity2.x, entity1.x) <= Math.min(entity2.x + entity2.img.width, entity1.x + entity1.img.width)) && (Math.max(entity2.y, entity1.y) <= Math.min(entity2.y + entity2.img.height, entity1.y + entity1.img.height)) ;
}


var collision_joueur = function(){                 //Fonction gérant la collision entre le joueur et les ennemis
	for (i=0;i<tship.length;i++){
		if (collision(joueur,tship[i])){
			joueur.pv-=1;
			joueurinvincible();
			tship[i].pv-=5;
			break;
		}
	}
		
}


var tirReussi = function (){           			 //Fonction permettant de gérer les collisions de type tir / ennemis   
	for (i=0;i<ttir.length;i++){                 //Cette fonction ne renvoie rien cas j'y ai instauré un système de PV. Pour la même raison elle ne prend pas d'arguments
		for (j=0;j<tship.length;j++){            // On ballaye le tableau des tirs alliés puis des tirs ennemis
			if(tship[j].type!="bullet"){         // Si l'ennemi n'est pas un tir alors on peut le toucher
				if (collision(ttir[i],tship[j])){                               // Si il y a collision
				ttir[i].pv -=1;
				tship[j].pv -= damagejoueur ;}                                  // alors on baisse les pvs
			}
		}
	}
}

var collisionpowerup= function(){             // Fonction veréifinat si il y a des collisions entre le joueur et les powerup
	for (i=0;i<tpowerup.length;i++)           // pour tous les powerup
		if (collision(joueur,tpowerup[i])){
			if (tpowerup[i].type == "bluefireball"){ // si le powerup est une bluefireball
				damagejoueur=2;                      // Les dommages du joueur sont doublés
				timgtir=["images/blue_fireball1.png","images/blue_fireball2.png","images/blue_fireball3.png"];
				soundfireball.play();
			}
			else if (tpowerup[i].type == "life"){       // Si le powerup est un coeur
				joueur.pv+=1
				soundlife.play();
			}
			else if (tpowerup[i].type == "coin"){
				score.textContent=parseInt(score.textContent) +valeurgold;
				coinsound.play()
			}
			tpowerup.splice(i,1);                    // on supprime l'entité après avoir appliqué les effets
			i--;
		}
}
	




var PV = function(){                  // Fonction permettant de regarder les PV de chaque entité du jeu et par la même occasion d'effectuer
	for (i=0;i<ttir.length;i++){      // certaines taches liées, comme les détruires gérer des animations, augmenter le score etc...
		if (ttir[i].pv <= 0){         // Pour tous nos tirs, on regarde si ils sont détruits
			ttir.splice(i,1);
			i--;
		}
	}
	for (i=0;i<tship.length;i++){                                       // On fait une bloucle pour les ennemis
		if (tship[i].pv <= 0){
			
			if (tship[i].type=="redrobot"){                             // Si l'ennemi détruit est un robot rouge
				if(Math.random() < coeffdroppu){
					powerup(tship[i].x,tship[i].y);                     // on a une chance d'avoir un powerup
				}
				score.textContent=parseInt(score.textContent) +750;     // si ils meurent on ajoute du score, on les supprime et on augmente la difficulté
				explosion.play();
			}
			
			else if ((tship[i].type=="greenrobot")){                    // Si l'ennemi détruit est un robot vert
				score.textContent=parseInt(score.textContent) +500;
				explosion.play();
			}
			
			else if (tship[i].type=="coinrobot"){                       // Si l'nnemi détruit est un coinrobot on fait pop une pièce
				powerupcoin(tship[i].x,tship[i].y);
				explosion.play();
			}
			else if (tship[i].type=="greendragon"){                     // Si l'ennemi est un dragon vert
				if(Math.random() < (7*coeffdroppu)){
					powerup(tship[i].x,tship[i].y);					    // on a une chance d'avoir un powerup
				}
				cridragon.play();
				score.textContent=parseInt(score.textContent) +2500;
				
			}
			else if (tship[i].type=="blackdragon"){                     // Si l'ennemi est un dragon vert
				powerup(tship[i].x,tship[i].y);                     // on a un powerup				
				cridragon.play();
				score.textContent=parseInt(score.textContent) +5000;
			}
			
			
			coeff_flotte+=spawnrate;                                    // on augmente la fréquence d'ennemis
			tship[i].mort=0;                                            // on crée une propriété mort pour pouvoir l'animer
			tmort.push(tship[i]);                                       // on ajoute l'entité au tableau des morts pour voir l'animer
			tship.splice(i,1);                                          // on supprime les ennemis si ils sont morts
			i--;
		}	
	}
	vies.textContent="x"+joueur.pv                                      // On affiche les vies du joueur
	if(joueur.pv==0){                                                   // Si on perd on lance le message de fin
		endgame();
		return true;                                                    // Les returns permettent si le joueur est mort de return true ce qui dans la boucle animation, va la stopper
	}
	else{
		return false;
	}
}


 /**************************************************************************************
 *                                  Gameplay & animations                              *
 **************************************************************************************/
 
// Fonctions sets de difficultés 
 
var diffacile = function(){           // fonction permettant de gérer les boutons de difficulté
	this.blur();
	restart();
	facile.removeEventListener("click",diffacile);
	coeffdroppu = 0.12;
	musique.src = "sounds/stage1.mp3";
	valeurgold = 5000
	myCanvas.style.backgroundImage= "url("+background[0]+")";
	difficulte = "facile"
	switch_flotte == true
	inflotte();
}

var difmoyen = function(){           // fonction permettant de gérer les boutons de difficulté
	this.blur();
	restart();
	moyen.removeEventListener("click",difmoyen);
	coeffdroppu = 0.10;
	musique.src = "sounds/stage2.mp3";
	valeurgold = 15000;
	pvgreenrobot = 6;
    pvredrobot = 8;
	coeff_flottemax = 0.075;
	myCanvas.style.backgroundImage= "url("+background[1]+")";
	difficulte = "moyenne"
	switch_flotte == true
	inflotte();
}
var difdifficile = function(){           // fonction permettant de gérer les boutons de difficulté
	this.blur();
	restart();
	difficile.removeEventListener("click",difdifficile);
	coeffdroppu = 0.09;
	valeurgold = 25000;
	pvgreenrobot = 7;  
    pvredrobot = 9;
	coeff_flottemax = 0.08;
	musique.src = "sounds/stage3.mp3";
	myCanvas.style.backgroundImage= "url("+background[2]+")";
	difficulte = "difficile"
	switch_flotte == true
	inflotte();
}


// Fonctions d'invincibilité

var joueurinvincible=function(){       // Fonction permettant de rendre invincible le joueur après s'être fait touché
	joueur.etat="invincible";
	timeinvincible = window.setInterval(stopinvincible,3000);
	}

var stopinvincible =function(){         // Fonction permettant de stopper l'invincibilité
	joueur.etat="vivant";
	clearInterval(timeinvincible);
}



/**************************************************************************************
*                                        Load                                         *
**************************************************************************************/

window.addEventListener("load",modifhtml);      // On charge la fonction pour qu'elle modifie l'HTML
window.addEventListener("load",init);           // On charge la fonction qui initialise le jeu
