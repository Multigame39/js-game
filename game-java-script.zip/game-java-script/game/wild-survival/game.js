// ================= SCÈNE =================
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87ceeb);

// ================= CAMÉRA FPS =================
const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
camera.position.y = 1.6;

// ================= RENDER =================
const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// ================= LUMIÈRE =================
let sun = new THREE.DirectionalLight(0xffffff, 1);
sun.position.set(50, 100, 50);
scene.add(new THREE.AmbientLight(0xffffff, 0.3));
scene.add(sun);

// ================= SOL =================
const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(500, 500),
    new THREE.MeshStandardMaterial({color:0x2ecc71})
);
ground.rotation.x = -Math.PI/2;
scene.add(ground);

// ================= JOUEUR =================
const player = {
    velocityY: 0,
    onGround: true,
    hp: 100,
    inventory: {
        wood: 0,
        stone: 0,
        dagger: false
    }
};

// ================= CONTRÔLES =================
const keys = {};
document.addEventListener("keydown", e => keys[e.key.toLowerCase()] = true);
document.addEventListener("keyup", e => keys[e.key.toLowerCase()] = false);

// ================= ROTATION CAMÉRA =================
let yaw = 0, pitch = 0;
document.addEventListener("keydown", e => {
    if(e.key === "ArrowLeft") yaw += 0.05;
    if(e.key === "ArrowRight") yaw -= 0.05;
    if(e.key === "ArrowUp") pitch += 0.05;
    if(e.key === "ArrowDown") pitch -= 0.05;
});

// ================= MONDE =================
const trees = [];
const mountains = [];
const monsters = [];

// Arbres
for(let i=0;i<80;i++){
    const tree = new THREE.Mesh(
        new THREE.CylinderGeometry(0.3,0.5,4),
        new THREE.MeshStandardMaterial({color:0x8b4513})
    );
    const leaves = new THREE.Mesh(
        new THREE.SphereGeometry(1.5),
        new THREE.MeshStandardMaterial({color:0x006400})
    );
    tree.position.set(Math.random()*400-200,2,Math.random()*400-200);
    leaves.position.set(tree.position.x, tree.position.y+3, tree.position.z);
    trees.push(tree);
    scene.add(tree);
    scene.add(leaves);
}

// Montagnes
for(let i=0;i<20;i++){
    const m = new THREE.Mesh(
        new THREE.ConeGeometry(10,30,8),
        new THREE.MeshStandardMaterial({color:0x808080})
    );
    m.position.set(Math.random()*400-200,15,Math.random()*400-200);
    mountains.push(m);
    scene.add(m);
}

// ================= JOUR / NUIT =================
let time = 0;
let isNight = false;

function updateDayNight(){
    time += 0.001;
    const intensity = Math.sin(time) * 0.5 + 0.5;
    sun.intensity = intensity;

    isNight = intensity < 0.25;
    scene.background = new THREE.Color(isNight ? 0x02020a : 0x87ceeb);

    document.getElementById("time").innerText = isNight ? "🌙 Nuit" : "☀️ Jour";

    if(isNight && monsters.length < 5){
        spawnMonster();
    }
}

// ================= MONSTRES =================
function spawnMonster(){
    const monster = new THREE.Mesh(
        new THREE.BoxGeometry(1,2,1),
        new THREE.MeshStandardMaterial({color:0xaa0000})
    );
    monster.position.set(
        camera.position.x + Math.random()*20-10,
        1,
        camera.position.z + Math.random()*20-10
    );
    monsters.push(monster);
    scene.add(monster);
}

// ================= ATTAQUE =================
document.addEventListener("click", () => {
    if(!player.inventory.dagger) return;

    monsters.forEach((m,i)=>{
        if(m.position.distanceTo(camera.position) < 2){
            scene.remove(m);
            monsters.splice(i,1);
        }
    });
});

// ================= BOUCLE JEU =================
function animate(){
    requestAnimationFrame(animate);

    // Déplacement FPS
    const speed = 0.15;
    if(keys["z"]) {
        camera.position.x -= Math.sin(yaw)*speed;
        camera.position.z -= Math.cos(yaw)*speed;
    }
    if(keys["s"]) {
        camera.position.x += Math.sin(yaw)*speed;
        camera.position.z += Math.cos(yaw)*speed;
    }
    if(keys["q"]) {
        camera.position.x -= Math.cos(yaw)*speed;
        camera.position.z += Math.sin(yaw)*speed;
    }
    if(keys["d"]) {
        camera.position.x += Math.cos(yaw)*speed;
        camera.position.z -= Math.sin(yaw)*speed;
    }

    // Gravité
    player.velocityY -= 0.02;
    camera.position.y += player.velocityY;
    if(camera.position.y < 1.6){
        camera.position.y = 1.6;
        player.velocityY = 0;
        player.onGround = true;
    }

    if(keys[" "] && player.onGround){
        player.velocityY = 0.35;
        player.onGround = false;
    }

    camera.rotation.set(pitch, yaw, 0);

    // Monstres suivent
    monsters.forEach(m=>{
        m.lookAt(camera.position);
        m.position.add(
            m.getWorldDirection(new THREE.Vector3()).multiplyScalar(0.03)
        );

        if(m.position.distanceTo(camera.position) < 1.5){
            player.hp -= 0.1;
        }
    });

    updateDayNight();

    document.getElementById("hp").innerText = "❤️ " + Math.floor(player.hp);
    document.getElementById("inventory").innerText =
        `🎒 Bois:${player.inventory.wood} Pierre:${player.inventory.stone} Dague:${player.inventory.dagger ? "✔" : "❌"}`;

    renderer.render(scene, camera);
}

animate();

// ================= RESIZE =================
window.addEventListener("resize", ()=>{
    camera.aspect = window.innerWidth/window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});
