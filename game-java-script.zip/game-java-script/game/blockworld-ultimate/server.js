const WebSocket = require("ws");
const wss = new WebSocket.Server({ port:8080 });
const players={};

wss.on("connection",ws=>{
  const id=Math.random().toString(36).slice(2);
  players[id]={x:0,y:2,z:0};

  ws.on("message",m=>{
    players[id]={...players[id],...JSON.parse(m)};
    wss.clients.forEach(c=>{
      if(c.readyState===1)
        c.send(JSON.stringify({players}));
    });
  });

  ws.on("close",()=>delete players[id]);
});
console.log("Serveur lancé sur ws://localhost:8080");
