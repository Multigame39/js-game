// ===== SCÈNE =====
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87ceeb);

const camera = new THREE.PerspectiveCamera(75, innerWidth/innerHeight, 0.1, 1000);
camera.position.set(0,2,5);

const renderer = new THREE.WebGLRenderer();
renderer.setSize(innerWidth, innerHeight);
document.body.appendChild(renderer.domElement);

// ===== LUMIÈRE =====
scene.add(new THREE.AmbientLight(0xffffff,0.4));
const sun = new THREE.DirectionalLight(0xffffff,1);
sun.position.set(50,100,50);
scene.add(sun);

// ===== JOUEUR =====
let yaw=0,pitch=0,velY=0,onGround=true,hp=100,time=0;
const keys={}, blocks=[], monsters=[], players={};
const inv={wood:0,stone:0,sword:false,bed:0};

// ===== CONTROLES =====
addEventListener("keydown",e=>keys[e.key.toLowerCase()]=true);
addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);
addEventListener("mousemove",e=>{
  if(document.pointerLockElement===document.body){
    yaw-=e.movementX*0.002;
    pitch-=e.movementY*0.002;
    pitch=Math.max(-1.5,Math.min(1.5,pitch));
  }
});
document.body.onclick=()=>document.body.requestPointerLock();

// ===== TEXTURES PAR DEFAUT =====
function makeTex(c1,c2){
  const s=16,cv=document.createElement("canvas");
  cv.width=cv.height=s;
  const ctx=cv.getContext("2d");
  for(let x=0;x<s;x++)for(let y=0;y<s;y++){
    ctx.fillStyle=Math.random()>.5&&c2?c2:c1;
    ctx.fillRect(x,y,1,1);
  }
  const t=new THREE.CanvasTexture(cv);
  t.magFilter=t.minFilter=THREE.NearestFilter;
  return t;
}

const fallback={
  grass:makeTex("#2ecc71","#27ae60"),
  dirt:makeTex("#964B00"),
  stone:makeTex("#777","#555"),
  wood:makeTex("#8b4513","#a0522d"),
  leaf:makeTex("#228b22","#32cd32"),
  bed:makeTex("#ff5555","#ff8888")
};

const resourcePack={};

// ===== IMPORT PACK MINECRAFT =====
document.getElementById("rp").onchange=async e=>{
  const zip=await JSZip.loadAsync(e.target.files[0]);
  async function load(p){
    const f=zip.file(p); if(!f) return null;
    const img=await createImageBitmap(await f.async("blob"));
    const t=new THREE.Texture(img);
    t.needsUpdate=true;
    t.magFilter=t.minFilter=THREE.NearestFilter;
    return t;
  }
  resourcePack.grass=await load("assets/minecraft/textures/block/grass_block_top.png");
  resourcePack.dirt =await load("assets/minecraft/textures/block/dirt.png");
  resourcePack.stone=await load("assets/minecraft/textures/block/stone.png");
  resourcePack.wood =await load("assets/minecraft/textures/block/oak_log.png");
  resourcePack.leaf =await load("assets/minecraft/textures/block/oak_leaves.png");
  alert("Resource pack chargé");
};

// ===== BLOCS =====
function mat(type){
  return new THREE.MeshStandardMaterial({
    map:resourcePack[type]||fallback[type]
  });
}

function block(x,y,z,type){
  const b=new THREE.Mesh(new THREE.BoxGeometry(1,1,1),mat(type));
  b.position.set(x,y,z);
  b.userData.type=type;
  scene.add(b); blocks.push(b);
}

// ===== MONDE =====
for(let x=-20;x<20;x++)for(let z=-20;z<20;z++){
  block(x,0,z,"grass");
  if(Math.random()<0.05) block(x,1,z,"wood");
}

// ===== MONSTRES =====
function spawnMonster(){
  const m=new THREE.Mesh(
    new THREE.BoxGeometry(1,2,1),
    new THREE.MeshStandardMaterial({color:0xaa0000})
  );
  m.position.set(
    camera.position.x+Math.random()*10-5,
    1,
    camera.position.z+Math.random()*10-5
  );
  scene.add(m); monsters.push(m);
}

// ===== MULTIJOUEUR =====
const socket=new WebSocket("ws://localhost:8080");
socket.onmessage=e=>{
  const data=JSON.parse(e.data);
  for(const id in data.players){
    if(!players[id]){
      players[id]=new THREE.Mesh(
        new THREE.BoxGeometry(1,2,1),
        new THREE.MeshStandardMaterial({color:0x0000ff})
      );
      scene.add(players[id]);
    }
    players[id].position.set(
      data.players[id].x,
      data.players[id].y,
      data.players[id].z
    );
  }
};

// ===== INVENTAIRE =====
function updateInv(){
  const d=document.getElementById("inv"); d.innerHTML="";
  for(let k in inv){
    const s=document.createElement("div");
    s.className="inv-slot";
    s.textContent=typeof inv[k]==="boolean"?inv[k]?"✔":"✖":inv[k];
    d.appendChild(s);
  }
}

// ===== ANIMATION =====
function animate(){
  requestAnimationFrame(animate);

  const sp=0.1;
  if(keys.z){camera.position.x-=Math.sin(yaw)*sp;camera.position.z-=Math.cos(yaw)*sp;}
  if(keys.s){camera.position.x+=Math.sin(yaw)*sp;camera.position.z+=Math.cos(yaw)*sp;}
  if(keys.q){camera.position.x-=Math.cos(yaw)*sp;camera.position.z+=Math.sin(yaw)*sp;}
  if(keys.d){camera.position.x+=Math.cos(yaw)*sp;camera.position.z-=Math.sin(yaw)*sp;}

  velY-=0.02; camera.position.y+=velY;
  if(camera.position.y<2){camera.position.y=2;velY=0;onGround=true;}
  if(keys[" "]&&onGround){velY=0.35;onGround=false;}

  camera.rotation.set(pitch,yaw,0);

  time+=0.001;
  sun.intensity=Math.sin(time)*0.5+0.5;
  if(sun.intensity<0.25 && monsters.length<5) spawnMonster();

  monsters.forEach(m=>{
    m.lookAt(camera.position);
    m.position.add(m.getWorldDirection(new THREE.Vector3()).multiplyScalar(0.03));
    if(m.position.distanceTo(camera.position)<1.5) hp-=0.1;
  });

  socket.send(JSON.stringify({
    x:camera.position.x,
    y:camera.position.y,
    z:camera.position.z,
    hp
  }));

  document.getElementById("hp").textContent="❤️ "+Math.floor(hp);
  document.getElementById("time").textContent=sun.intensity<0.25?"🌙 Nuit":"☀️ Jour";
  updateInv();

  renderer.render(scene,camera);
}
animate();
