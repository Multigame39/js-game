let scene, camera, renderer;
let player, crystals = [], portal;
let keys = {};
let velocityY = 0;
let onGround = true;

// ================= DÉMARRER =================
function startGame(){
    document.getElementById("menu").style.display = "none";
    init();
    animate();
}

// ================= INIT =================
function init(){
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87ceeb);

    camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);

    renderer = new THREE.WebGLRenderer({antialias:true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(renderer.domElement);

    // Lumières
    scene.add(new THREE.AmbientLight(0xffffff, 0.5));
    const sun = new THREE.DirectionalLight(0xffffff, 1);
    sun.position.set(10, 20, 10);
    scene.add(sun);

    // Sol (île)
    const ground = new THREE.Mesh(
        new THREE.CircleGeometry(80, 64),
        new THREE.MeshStandardMaterial({color:0x2ecc71})
    );
    ground.rotation.x = -Math.PI/2;
    scene.add(ground);

    // Joueur
    player = new THREE.Mesh(
        new THREE.BoxGeometry(1,2,1),
        new THREE.MeshStandardMaterial({color:0x3498db})
    );
    player.position.y = 1;
    scene.add(player);

    // Cristaux
    for(let i=0;i<5;i++){
        const crystal = new THREE.Mesh(
            new THREE.OctahedronGeometry(0.7),
            new THREE.MeshStandardMaterial({color:0x00ffff, emissive:0x0088ff})
        );
        crystal.position.set(
            Math.random()*50-25,
            1,
            Math.random()*50-25
        );
        crystals.push(crystal);
        scene.add(crystal);
    }

    // Portail
    portal = new THREE.Mesh(
        new THREE.TorusGeometry(2,0.4,16,32),
        new THREE.MeshStandardMaterial({color:0xff00ff, emissive:0x550055})
    );
    portal.position.set(0,2,-40);
    scene.add(portal);

    // Contrôles
    document.addEventListener("keydown", e => keys[e.key.toLowerCase()] = true);
    document.addEventListener("keyup", e => keys[e.key.toLowerCase()] = false);

    window.addEventListener("resize", resize);
}

// ================= BOUCLE =================
function animate(){
    requestAnimationFrame(animate);

    // Déplacements
    if(keys["z"]) player.position.z -= 0.15;
    if(keys["s"]) player.position.z += 0.15;
    if(keys["q"]) player.position.x -= 0.15;
    if(keys["d"]) player.position.x += 0.15;

    // Saut
    if(keys[" "] && onGround){
        velocityY = 0.35;
        onGround = false;
    }

    velocityY -= 0.02;
    player.position.y += velocityY;

    if(player.position.y <= 1){
        player.position.y = 1;
        velocityY = 0;
        onGround = true;
    }

    // Caméra aventure
    camera.position.set(
        player.position.x,
        player.position.y + 6,
        player.position.z + 10
    );
    camera.lookAt(player.position);

    // Cristaux (collecte)
    crystals.forEach((c, i)=>{
        c.rotation.y += 0.05;
        if(player.position.distanceTo(c.position) < 1.5){
            scene.remove(c);
            crystals.splice(i,1);
        }
    });

    // Victoire
    if(crystals.length === 0 && player.position.distanceTo(portal.position) < 3){
        alert("🏆 VOUS AVEZ TERMINÉ L’AVENTURE !");
        location.reload();
    }

    portal.rotation.y += 0.03;

    renderer.render(scene, camera);
}

// ================= RESIZE =================
function resize(){
    camera.aspect = window.innerWidth/window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}
