import tkinter as tk
from datetime import datetime
import random
import time
import threading
import pygame

# ---------------- CONFIG ----------------
FIREWORK_DURATION = 120  # Durée feu d’artifice en secondes
NEON_BG = "#3b005f"
NEON_BOX = "#5a008a"
NEON_TEXT = "#ff00ff"
MP3_FILE = "explosion.mp3"  # Place ce fichier dans le même dossier que le script

# ---------------- INIT SON ----------------
pygame.mixer.init()
explosion_sound = pygame.mixer.Sound(MP3_FILE)

# ---------------- TIMER ----------------
def update_timer():
    global fireworks_active

    if fireworks_active:
        return

    now = datetime.now()
    year = now.year
    end_year = datetime(year, 12, 31, 23, 59, 59)

    if now >= end_year:
        start_fireworks()
        return

    remaining = end_year - now
    total = int(remaining.total_seconds())

    m, s = divmod(total, 60)
    h, m = divmod(m, 60)
    d, h = divmod(h, 24)
    w, d = divmod(d, 7)
    mo = w // 4
    w %= 4

    data = [mo, w, d, h, m, s]
    for key, val in zip(values.keys(), data):
        values[key].config(text=val)

    title.config(text=f"⏳ Temps restant avant {year + 1}")
    root.after(1000, update_timer)

# ---------------- PARTICULE ----------------
class Particle:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.vx = random.uniform(-8, 8)
        self.vy = random.uniform(-8, 8)
        self.life = random.randint(20, 50)
        self.color = random.choice(["#ff00ff", "#00ffff", "#ffff00", "#ff6600"])

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.vy += 0.2
        self.life -= 1

    def draw(self):
        canvas.create_oval(
            self.x - 5, self.y - 5,
            self.x + 5, self.y + 5,
            fill=self.color, outline=""
        )

# ---------------- FEU D’ARTIFICE ----------------
def start_fireworks():
    global fireworks_active, start_time, particles
    fireworks_active = True
    start_time = time.time()
    particles = []

    title.config(text="🎉 BONNE ANNÉE 🎉")
    canvas.pack(fill="both", expand=True)

    threading.Thread(target=sound_loop, daemon=True).start()
    animate_fireworks()

def sound_loop():
    while fireworks_active:
        explosion_sound.play()
        time.sleep(1)

def animate_fireworks():
    global particles

    if time.time() - start_time > FIREWORK_DURATION:
        stop_fireworks()
        return

    canvas.delete("all")

    if random.random() < 0.3:
        x = random.randint(100, root.winfo_width() - 100)
        y = random.randint(100, root.winfo_height() - 200)
        for _ in range(60):
            particles.append(Particle(x, y))

    for p in particles[:]:
        p.update()
        p.draw()
        if p.life <= 0:
            particles.remove(p)

    root.after(33, animate_fireworks)

def stop_fireworks():
    global fireworks_active
    fireworks_active = False
    canvas.pack_forget()
    update_timer()

# ---------------- INTERFACE ----------------
root = tk.Tk()
root.title("Timer Annuel Néon 🎆")
root.configure(bg=NEON_BG)

# Plein écran
root.attributes("-fullscreen", True)

# Frame pour centrer le timer
frame = tk.Frame(root, bg=NEON_BG)
frame.pack(expand=True)

values = {}

# Fonction pour calculer la taille de la police selon la taille de l’écran
def calc_font_sizes():
    width = root.winfo_width()
    height = root.winfo_height()
    title_size = max(24, width // 25)
    value_size = max(20, width // 30)
    unit_size = max(12, width // 60)
    return title_size, value_size, unit_size

# Titre principal
title = tk.Label(root, text="⏳ Timer Annuel", fg=NEON_TEXT, bg=NEON_BG)
title.pack(pady=40)

def create_unit(name):
    box = tk.Frame(frame, bg=NEON_BOX)
    box.pack(side="left", padx=15, expand=True, fill="both")

    val = tk.Label(box, text="0", fg="#00ffff", bg=NEON_BOX)
    val.pack(expand=True)

    lab = tk.Label(box, text=name, fg="white", bg=NEON_BOX)
    lab.pack()

    values[name] = val

for unit in ["Mois", "Semaines", "Jours", "Heures", "Minutes", "Secondes"]:
    create_unit(unit)

canvas = tk.Canvas(root, bg="black", highlightthickness=0)
fireworks_active = False
particles = []

# Mettre la taille des polices à l’écran
def resize_fonts(event=None):
    title_size, value_size, unit_size = calc_font_sizes()
    title.config(font=("Arial", title_size, "bold"))
    for key, val in values.items():
        val.config(font=("Arial", value_size, "bold"))
    for child in frame.winfo_children():
        for l in child.winfo_children():
            if l not in values.values():
                l.config(font=("Arial", unit_size, "bold"))

root.bind("<Configure>", resize_fonts)

# Sortir du plein écran avec Échap
def quit_fullscreen(event):
    root.destroy()

root.bind("<Escape>", quit_fullscreen)

# ---------------- LANCEMENT ----------------
update_timer()
resize_fonts()
root.mainloop()
